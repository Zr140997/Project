
function kiemTraThongTin() {
     kiemTraDanhXung();
     kiemTraHoTen();
     kiemTraSoDienThoai();
}
   
  function kiemTraDanhXung() {
    let danhXungAnh = document.querySelector("#anh").checked;
    let danhXungChi = document.querySelector("#chi").checked;
    let thongBaoDanhXung = document.querySelector("#thongBaoDanhXung");
  
    if (!danhXungAnh && !danhXungChi) {
      thongBaoDanhXung.style.display = "block";
      return false; // Trả về false nếu không có danh xưng nào được chọn
    } else {
      thongBaoDanhXung.style.display = "none";
      return true; // Trả về true nếu có ít nhất một danh xưng được chọn
    }
  }
  function kiemTraHoTen() {
    let hotenInput = document.querySelector("#hoten");
    let thongBaoHoTen = document.querySelector("#thongBaoHoTen");
  
    if (hotenInput.value === "") {
      thongBaoHoTen.style.display = "block";
      return false; // Trả về false nếu họ tên không được nhập
    } else {
      thongBaoHoTen.style.display = "none";
      return true; // Trả về true nếu họ tên đã được nhập
    }
  }
  function kiemTraSoDienThoai() {
    let sodienthoaiInput = document.querySelector("#sodienthoai");
    let thongBaoSoDienThoai = document.querySelector("#thongBaoSoDienThoai");
  
    // Kiểm tra số điện thoại có để trống hay không
    if (sodienthoaiInput.value === "") {
      thongBaoSoDienThoai.textContent = "* Vui lòng nhập số điện thoại";
      thongBaoSoDienThoai.style.display = "block";
      return false; // Trả về false nếu số điện thoại để trống
    }
  
    // Biểu thức chính quy để kiểm tra số điện thoại
    let kiemtrasdt = /^(0\d{9})|\+84\d{9}$/;
  
    if (!kiemtrasdt.test(sodienthoaiInput.value)) {
      thongBaoSoDienThoai.textContent = "* Số điện thoại không hợp lệ";
      thongBaoSoDienThoai.style.display = "block";
      return false; // Trả về false nếu số điện thoại không đúng định dạng
    } else {
      thongBaoSoDienThoai.style.display = "none";
      return true; // Trả về true nếu số điện thoại đúng định dạng
    }
  }
  
  let hoanTatDatHangButton = document.querySelector("#hoantat");
  hoanTatDatHangButton.addEventListener("click", kiemTraThongTin);
      
    


  
  



  function chonAnhChiTiet(evtObj) {
   
    let anhLon = document.querySelector('#changeimg');
    let text =document.querySelector('#text');
    // Đổi ảnh lớn thành ảnh nhấn
    anhLon.src = evtObj.target.src;

    let textElement = evtObj.target.nextElementSibling;
    if (textElement.tagName !== 'P') {
    textElement = textElement.nextElementSibling;
  }

  // Thay đổi text miêu tả
  text.innerHTML = textElement.innerHTML;
  }

  // Gắn sự kiện nhấn vào từng ảnh chi tiết
  let anhChiTiet = document.querySelectorAll('.anhchitiet img');
  for (let i = 0; i < anhChiTiet.length; i++) {
    anhChiTiet[i].addEventListener('click', chonAnhChiTiet);
  }


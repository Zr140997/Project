let cartData = JSON.parse(sessionStorage.getItem('cartgiohang')) || [];


if (cartData) {
    let cartTable = document.querySelector('#cart-table');
    function createTableRow(item) {
        let tr = document.createElement("tr");

        let td_image = document.createElement('td');
        let image = document.createElement('img');
        image.src = item.image;
        image.alt = "Product image";
        td_image.appendChild(image);

        let td_name = document.createElement('td');
        td_name.innerText = item.name;

        let td_price = document.createElement('td');
        td_price.innerText = item.price;

        let td_bttn = document.createElement('td');
        let deleteButton = document.createElement('button');
        deleteButton.innerText = "Xoá";
        deleteButton.addEventListener('click', function () {
            xoaSanPham(item, tr);
        });
        td_bttn.appendChild(deleteButton);

        tr.appendChild(td_image);
        tr.appendChild(td_name);
        tr.appendChild(td_price);
        tr.appendChild(td_bttn);

        return tr;
    }

    let sanPham = document.createElement("h1");
    sanPham.textContent = "GIỎ HÀNG CỦA BẠN";
    
    cartTable.appendChild(sanPham);
   
    for (let i = 0; i < cartData.length; ++i) {
        let tr = createTableRow(cartData[i]);
        cartTable.appendChild(tr);
     
    }
    let p1 = document.createElement("p");
    p1.id = "count";
    cartTable.appendChild(p1);
    tinhSoLuong()
    let p2 = document.createElement("p");
    p2.id = "total";
    cartTable.appendChild(p2);
    tinhTongTien();
    
    // Tính tổng tiền của các sản phẩm trong giỏ hàng
    function tinhTongTien() {
        let tongTien = 0;
        for (let i = 0; i < cartData.length; i++) {
            tongTien += eval(cartData[i].price);
        }
        let p2 = document.getElementById("total");
        p2.textContent = "Tổng tiền: " + tongTien + " VND";
        p2.style.fontSize="20px";

        return tongTien;
    }
    // Đếm số lượng sản phẩm trong giỏ hàng
    function tinhSoLuong() {
        let soLuong = 0;
        for (let i = 0; i < cartData.length; i++) {
            soLuong++;
        }
        let p1 = document.getElementById("count");
        p1.textContent = "Số lượng: " + soLuong ;

        return soLuong;
    }
    function xoaSanPham(item, tr) {
        let index = cartData.indexOf(item);
        if (index !== -1) {
            cartData.splice(index, 1);
            sessionStorage.setItem('cartgiohang', JSON.stringify(cartData));
            tr.remove(); // Xóa hàng tương ứng 
            tinhSoLuong();
            tinhTongTien();
        }
    }
    


    

   
}






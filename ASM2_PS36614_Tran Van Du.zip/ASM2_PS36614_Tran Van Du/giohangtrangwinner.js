class Item {
    constructor(image, name, price) {
      this.image = image;
      this.name = name;
      this.price = price;
    }
  }
  
  let product = [
    new Item("https://cdn.honda.com.vn/motorbikes/December2021/k3wLSQfryNBCNFLVS9Bq.png", "Winner X", 46160000 ),
    
  ];
  let cart = JSON.parse(sessionStorage.getItem('cartgiohang')) || [];

  function addToCart() {
      let image = product[0].image;
      let name = product[0].name;
      let price = product[0].price;
  
      let currentProduct = new Item(image, name, price);
  
      cart.push(currentProduct);
      sessionStorage.setItem('cartgiohang', JSON.stringify(cart));
  }
  
  let bttn = document.getElementById("add-to-cart-button");
  bttn.addEventListener("click", addToCart);
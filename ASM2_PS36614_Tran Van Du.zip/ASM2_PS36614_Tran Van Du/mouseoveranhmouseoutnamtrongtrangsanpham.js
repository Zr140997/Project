


 
 
  function showXemChiTiet(evtObj) {
    let xemchitietchange = this.querySelector('.xemchitiet');
    xemchitietchange.style.display = 'block';
  }

  function hideXemChiTiet(evtObj) {
    let xemchitietchange = this.querySelector('.xemchitiet');
    xemchitietchange.style.display = 'none';
  }

  let changeimgs = document.querySelectorAll('.anhxe');
  for (let i = 0; i < changeimgs.length; i++) {
  changeimgs[i].addEventListener('mouseover', showXemChiTiet);
  changeimgs[i].addEventListener('mouseout', hideXemChiTiet);
}

  
  